﻿using Microsoft.EntityFrameworkCore;
using MVC_EF_START_6.Models;
namespace MVC_EF_START_6.DataAccess
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Company> Companies { get; set; }
        public DbSet<Quote> Quotes { get; set; }
    }
}
